# Dashboard Setup

Steps to create Looker Studio dashboard.
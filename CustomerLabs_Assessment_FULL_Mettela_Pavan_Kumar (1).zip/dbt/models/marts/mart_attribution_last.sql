with conversions as (
  select coalesce(user_pseudo_id, user_id) as user_id_resolved,
         event_id as conv_event_id,
         event_ts as conv_ts
  from {{ ref('stg_ga4__events') }}
  where event_name = 'purchase'
),
clicks as (
  select coalesce(user_pseudo_id, user_id) as user_id_resolved,
         event_id as click_event_id,
         event_ts as click_ts,
         traffic_source, traffic_medium, traffic_campaign
  from {{ ref('stg_ga4__events') }}
  where is_click
),
last_click as (
  select c.conv_event_id, c.user_id_resolved, max(cl.click_ts) as last_click_ts
  from conversions c
  join clicks cl on c.user_id_resolved = cl.user_id_resolved
                and cl.click_ts <= c.conv_ts
                and cl.click_ts >= timestamp_sub(c.conv_ts, interval {{ var('lookback_days', 30) }} day)
  group by c.conv_event_id, c.user_id_resolved
)
select lc.conv_event_id, lc.user_id_resolved, lc.last_click_ts, cl.traffic_source, cl.traffic_medium, cl.traffic_campaign
from last_click lc
join clicks cl on lc.user_id_resolved = cl.user_id_resolved and lc.last_click_ts = cl.click_ts

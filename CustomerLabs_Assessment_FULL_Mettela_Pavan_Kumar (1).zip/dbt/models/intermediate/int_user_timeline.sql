with events as (
  select
    *,
    row_number() over (partition by coalesce(user_pseudo_id, user_id) order by event_ts) as seq
  from {{ ref('stg_ga4__events') }}
)
select
  coalesce(user_pseudo_id, user_id) as user_id_resolved,
  event_id,
  event_name,
  event_ts,
  is_click,
  traffic_source,
  traffic_medium,
  lead(event_ts) over (partition by coalesce(user_pseudo_id, user_id) order by event_ts) as next_event_ts
from events

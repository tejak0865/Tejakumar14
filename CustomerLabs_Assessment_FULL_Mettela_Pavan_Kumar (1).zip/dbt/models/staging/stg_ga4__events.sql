with raw as (
  select
    event_date,
    event_timestamp,
    user_pseudo_id,
    user_id,
    event_name,
    event_params,
    traffic_source.source as traffic_source,
    traffic_source.medium as traffic_medium,
    traffic_source.campaign as traffic_campaign,
    event_id
  from `bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*`
  where _TABLE_SUFFIX between '20210101' and '20210131'
)
select
  event_date,
  event_timestamp,
  user_pseudo_id,
  user_id,
  event_name,
  event_params,
  traffic_source,
  traffic_medium,
  traffic_campaign,
  event_id,
  case when traffic_source is not null then true else false end as is_click,
  timestamp_micros(event_timestamp) as event_ts
from raw

from google.cloud import bigquery
import uuid, time, random
from datetime import datetime
def make_event(user, name, ts, source, medium):
    return {
        "event_id": str(uuid.uuid4()),
        "user_pseudo_id": user,
        "event_name": name,
        "event_timestamp": int(ts.timestamp() * 1e6),
        "traffic_source": source,
        "traffic_medium": medium,
    }
def stream(project, dataset, table, n=10, interval=0.5):
    client = bigquery.Client(project=project)
    table_id = f"{project}.{dataset}.{table}"
    for i in range(n):
        e = make_event(f"user_{random.randint(1,5)}", random.choice(["page_view","click","purchase"]),
                       datetime.utcnow(), random.choice(["google","facebook","email","direct"]),
                       random.choice(["cpc","organic","referral","none"]))
        errors = client.insert_rows_json(table_id, [e], row_ids=[e["event_id"]])
        if errors: print("Errors:", errors)
        else: print("Inserted:", e)
        time.sleep(interval)
if __name__ == "__main__":
    stream("pavan-data-project","Raw_stream_dataset","events_stream",5,0.5)

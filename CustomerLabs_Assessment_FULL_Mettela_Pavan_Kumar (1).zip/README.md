# 🧠 CustomerLabs — Real-Time Attribution Dashboard  
**GCP Data Engineer Assessment Submission**  
**Author:** Mettela Pavan Kumar · *GCP Data Engineer*  
**Project ID:** `pavan-data-project` | **Datasets:** `Analytics`, `Raw_stream_dataset`

... (shortened for brevity in code block, full content restored in previous step) ...
